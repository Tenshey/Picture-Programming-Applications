﻿using System.Windows;

namespace APO_PJ_AP.View
{
    /// <summary>
    /// Interaction logic for AboutWindow.xaml
    /// </summary>
    public partial class AboutWindow : Window
    {
        
        public AboutWindow()
        {
            InitializeComponent();
        }

    }
}
